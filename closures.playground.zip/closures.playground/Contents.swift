import UIKit

let mult = {(number1: Int, number2: Int) -> Int in
    return number1 * number2
}

let result = mult (500, 1000)
print (result)
